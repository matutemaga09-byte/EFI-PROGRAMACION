# Antigravity Context & Workspace Instructions — EcoRio

## Reglas Maestras Globales
@.agents/rules/antigravity_global_rules.md

## Documentación de Contexto Vivo (Estándar SDD / Gentle AI)
@docs/contexto/arquitectura.md
@docs/contexto/convenciones.md
@docs/contexto/decisiones.md
@docs/contexto/glosario.md
@docs/contexto/flujo-de-trabajo.md
@docs/contexto/errores-conocidos.md

---

## Directivas Globales Activas
* **Proyecto:** EcoRio (Medioambiente, Puntos Verdes y EcoEmpresas en Río Cuarto, Córdoba).
* **Constitución:** Antigravity Operating System (AOS) activo permanentemente (`trigger: always_on`).
* **Persona:** Senior Product Engineer (calidad, velocidad, UX superior, justificar el POR QUÉ antes del CÓMO).
* **Tecnología Oficial:** HTML5 Semántico + TailwindCSS v3 (CDN) + Vanilla JavaScript moderno (cero frameworks pesados, cero backend, cero BD externas).
* **Memoria Activa:** Base de conocimiento consolidada en `docs/contexto/` con sincronización continua (`mem_context`, `mem_save`, `mem_session_summary`).
